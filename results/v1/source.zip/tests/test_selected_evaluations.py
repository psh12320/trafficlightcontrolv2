import csv
from contextlib import contextmanager
from pathlib import Path

from scripts import run_selected_evaluations as selected


def test_scenario_preserves_different_baseline_and_learned_columns(tmp_path, monkeypatch):
    builds = []
    monkeypatch.setattr(selected, "build", lambda *args: builds.append(args))

    @contextmanager
    def pool(**kwargs):
        class InlinePool:
            def map(self, function, tasks):
                for controller, checkpoint, *_ in tasks:
                    row = {"seed": 11, "scenario_controller": controller,
                           "pedestrian_p95_by_crossing": {":J0_c0": 12.0}}
                    if checkpoint is None:
                        row["warmup_seconds"] = 60
                    else:
                        row["checkpoint"] = str(checkpoint)
                        row["vehicle_departed"] = 10
                    yield [row]
        yield InlinePool()

    monkeypatch.setattr(selected, "ProcessPoolExecutor", pool)
    output = selected.evaluate_scenario(
        "slow", [("ippo-vehicle-seed100", Path("selected.pt"))],
        [11], 3600, 0.9, 6, 20, tmp_path,
    )
    with output.open(newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))
    assert len(rows) == 3
    assert rows[0]["warmup_seconds"] == "60"
    assert rows[2]["checkpoint"] == "selected.pt"
    assert rows[2]["vehicle_departed"] == "10"
    assert rows[0]["pedestrian_p95_by_crossing"] == '{":J0_c0": 12.0}'
    assert builds == [(37, 0.9, 6)]
