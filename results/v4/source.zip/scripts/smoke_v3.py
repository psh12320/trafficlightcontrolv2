"""Small four-controller training/validation check; never uses final test seeds."""
import argparse
from argparse import Namespace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
local_deps = ROOT / "scenario/generated/v2-local-diagnostics/python-deps"
if local_deps.exists():
    sys.path.insert(0, str(local_deps))
from scripts.run_simulation import _import_traci
_import_traci()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from scripts.run_marl_sweep import main as sweep
    sweep(Namespace(output_root=args.output, seed=9980, episodes=2, horizon=120,
        randomize_demand=True, switch_penalty=8.0, skip_build=False,
        pedestrian_speed=1.4, vehicle_period=6, pedestrian_interval=20,
        algorithms=["ippo", "mappo"], reward_modes=["vehicle", "vehicle_pedestrian"],
        action_sizes=[2], evaluation_seeds=[9901, 9902, 9903],
        evaluation_duration=120, snapshot_interval=1))
    import torch
    checkpoints = list(args.output.glob("*/final.pt"))
    assert len(checkpoints) == 4
    for checkpoint in checkpoints:
        saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
        assert saved["metadata"]["observation_size"] == 21
        assert saved["metadata"]["action_size"] == 2
        assert saved["metadata"]["pedestrian_scale"] == 20
    print("V3_FOUR_CONTROLLER_SMOKE_PASSED", flush=True)


if __name__ == "__main__":
    main()
